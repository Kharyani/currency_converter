import json
from datetime import datetime
from config import HISTORY_FILE


def save_history(record):
    try:
        data = []

        try:
            with open(HISTORY_FILE, "r") as file:
                data = json.load(file)
        except:
            pass

        data.append(record)

        with open(HISTORY_FILE, "w") as file:
            json.dump(data, file, indent=4)

    except Exception as e:
        print("Error saving history:", e)


def view_history():
    try:
        with open(HISTORY_FILE, "r") as file:
            data = json.load(file)

            if not data:
                print("No history found.")
                return

            for item in data:
                print("\n========== TRANSACTION HISTORY ==========")
                print(f"From: {item['from']}")
                print(f"To: {item['to']}")
                print(f"Amount: {item['amount']}")
                print(f"Result: {item['result']}")
                print(f"Time: {item['time']}")

    except:
        print("No history available.")