from api import fetch_rates
from converter import convert_currency
from history import save_history, view_history
from utils import get_float_input
from datetime import datetime

def menu():
    print("\n====== CURRENCY CONVERTER ======")
    print("1. Convert Currency")
    print("2. View Exchange Rates")
    print("3. View History")
    print("4. Exit")

def convert():
    base = input("Enter base currency (e.g., USD): ").upper()
    target = input("Enter target currency (e.g., PKR): ").upper()
    amount = get_float_input("Enter amount: ")

    rates, error = fetch_rates(base)

    if error:
        print("Error:", error)
        return

    result = convert_currency(rates, base, target, amount)

    if result is None:
        print("Invalid target currency.")
        return

    print(f"\n💰 {amount:,.2f} {base} = {result:,.2f} {target}")

    record = {
        "from": base,
        "to": target,
        "amount": amount,
        "result": round(result, 2),
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    save_history(record)


def view_rates():
    base = input("Enter base currency: ").upper()
    rates, error = fetch_rates(base)

    if error:
        print("Error:", error)
        return

    print("\n📊 Exchange Rates:")
    for k, v in list(rates.items())[:10]:  # show first 10
        print(f"{k}: {v}")


def main():
    while True:
        menu()
        choice = input("Enter choice: ")

        if choice == "1":
            convert()
        elif choice == "2":
            view_rates()
        elif choice == "3":
            view_history()
        elif choice == "4":
            print("Exiting...")
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()