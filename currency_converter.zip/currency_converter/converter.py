def convert_currency(rates, from_currency, to_currency, amount):
    from_currency = from_currency.upper()
    to_currency = to_currency.upper()

    if to_currency not in rates:
        return None

    rate = rates[to_currency]
    return amount * rate