def get_float_input(prompt):
    while True:
        try:
            return float(input(prompt))
        except:
            print("Invalid amount. Try again.")