import requests
from config import BASE_URL

def fetch_rates(base_currency):
    try:
        url = BASE_URL + base_currency.upper()
        response = requests.get(url)

        if response.status_code != 200:
            return None, "API Error"

        data = response.json()

        if data["result"] != "success":
            return None, "Invalid Currency Code"

        return data["conversion_rates"], None

    except Exception as e:
        return None, str(e)