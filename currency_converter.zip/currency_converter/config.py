API_KEY = "b90b0867e02b1da0b26189d7"
BASE_URL = f"https://v6.exchangerate-api.com/v6/{API_KEY}/latest/"
HISTORY_FILE = "history.json"